<?php

declare(strict_types=1);

/**
 * Минимальная запись ZIP на чистом PHP — запасной вариант, если на сервере нет расширения zip (ZipArchive).
 * Поддерживает только то, что нужно сайту: addFromString(), addFile(), close(). Без ZIP64 (архивы до 4 ГБ).
 */
final class IroZipWriter
{
    /** @var resource */
    private $fp;

    private int $offset = 0;

    /** @var list<string> */
    private array $central = [];

    public function __construct(string $path)
    {
        $fp = @fopen($path, 'wb');
        if ($fp === false) {
            throw new RuntimeException('Не удалось открыть файл архива для записи');
        }
        $this->fp = $fp;
    }

    public function addFromString(string $name, string $data): bool
    {
        $crc = crc32($data);
        $size = strlen($data);
        $method = 0;
        $payload = $data;
        if (function_exists('gzdeflate')) {
            $deflated = gzdeflate($data, 6);
            if ($deflated !== false && strlen($deflated) < $size) {
                $method = 8;
                $payload = $deflated;
            }
        }
        $this->writeEntry($name, $method, $crc, strlen($payload), $size, static function ($fp) use ($payload): void {
            fwrite($fp, $payload);
        });

        return true;
    }

    /** Файл копируется потоком без сжатия, чтобы не держать большие вложения в памяти. */
    public function addFile(string $filePath, string $name): bool
    {
        $size = @filesize($filePath);
        $hash = @hash_file('crc32b', $filePath);
        if ($size === false || $hash === false) {
            return false;
        }
        $crc = (int) hexdec($hash);
        $this->writeEntry($name, 0, $crc, $size, $size, static function ($fp) use ($filePath): void {
            $in = fopen($filePath, 'rb');
            if ($in !== false) {
                stream_copy_to_stream($in, $fp);
                fclose($in);
            }
        });

        return true;
    }

    public function close(): bool
    {
        $cd = implode('', $this->central);
        fwrite($this->fp, $cd);
        $count = count($this->central);
        fwrite($this->fp, pack('VvvvvVVv', 0x06054b50, 0, 0, $count, $count, strlen($cd), $this->offset, 0));
        fclose($this->fp);

        return true;
    }

    private function writeEntry(string $name, int $method, int $crc, int $compSize, int $size, callable $writeData): void
    {
        $name = str_replace('\\', '/', $name);
        [$dosTime, $dosDate] = self::dosDateTime(time());
        // Бит 11 — имя в UTF-8 (кириллица в именах файлов участников).
        $flags = 0x0800;
        $local = pack('VvvvvvVVVvv', 0x04034b50, 20, $flags, $method, $dosTime, $dosDate, $crc, $compSize, $size, strlen($name), 0) . $name;
        fwrite($this->fp, $local);
        $writeData($this->fp);

        $this->central[] = pack(
            'VvvvvvvVVVvvvvvVV',
            0x02014b50, 20, 20, $flags, $method, $dosTime, $dosDate, $crc, $compSize, $size,
            strlen($name), 0, 0, 0, 0, 0, $this->offset
        ) . $name;
        $this->offset += strlen($local) + $compSize;
    }

    /** @return array{0: int, 1: int} */
    private static function dosDateTime(int $ts): array
    {
        $d = getdate($ts);
        $year = max(1980, $d['year']);

        return [
            ($d['hours'] << 11) | ($d['minutes'] << 5) | intdiv($d['seconds'], 2),
            (($year - 1980) << 9) | ($d['mon'] << 5) | $d['mday'],
        ];
    }
}

/**
 * Открыть архив на запись: ZipArchive, если расширение есть, иначе IroZipWriter.
 *
 * @return ZipArchive|IroZipWriter|null
 */
function iro_zip_open_for_write(string $path)
{
    if (class_exists(ZipArchive::class)) {
        $zip = new ZipArchive();

        return $zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true ? $zip : null;
    }
    try {
        return new IroZipWriter($path);
    } catch (RuntimeException $e) {
        return null;
    }
}
