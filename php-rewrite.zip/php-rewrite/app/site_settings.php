<?php

declare(strict_types=1);

/**
 * Настройки сайта, редактируемые администратором (таблица site_settings, ключ → значение).
 * Значения из БД перекрывают app/config.php; если строки нет — действует конфиг или значение по умолчанию.
 */

/** Ключ → [тип, значение по умолчанию]. Типы: string, text, bool, int, secret. */
function iro_settings_schema(): array
{
    return [
        'site_name' => ['string', 'Конкурсы'],
        'org_name' => ['string', 'ГУ ДПО «Институт развития образования Забайкальского края»'],
        'contact_phone' => ['string', '8 (3022) 41-54-29'],
        'contact_email' => ['string', 'cit@iro75.ru'],
        'org_site_url' => ['string', 'http://www.irozk.ru/'],
        'vk_url' => ['string', 'https://vk.com/gudpoirozk'],
        'footer_copyright' => ['string', 'ЦПТО'],

        'registration_enabled' => ['bool', '1'],

        'oauth_yandex_enabled' => ['bool', '0'],
        'oauth_yandex_client_id' => ['string', ''],
        'oauth_yandex_client_secret' => ['secret', ''],
        'oauth_yandex_redirect_uri' => ['string', ''],

        'mail_enabled' => ['bool', '0'],
        'mail_from_email' => ['string', ''],
        'mail_from_name' => ['string', ''],
        'mail_smtp_host' => ['string', ''],
        'mail_smtp_port' => ['int', '465'],
        'mail_smtp_encryption' => ['string', 'ssl'],
        'mail_smtp_user' => ['string', ''],
        'mail_smtp_pass' => ['secret', ''],

        'maintenance_enabled' => ['bool', '0'],
        'maintenance_title' => ['string', 'Сайт на техническом обслуживании'],
        'maintenance_message' => ['text', 'Проводятся плановые работы. Пожалуйста, зайдите позже.'],
        'maintenance_until' => ['string', ''],
        'maintenance_allowed_ips' => ['text', ''],
    ];
}

/** Секции страницы настроек: ключ секции → список ключей настроек. */
function iro_settings_sections(): array
{
    return [
        'general' => ['site_name', 'org_name', 'contact_phone', 'contact_email', 'org_site_url', 'vk_url', 'footer_copyright'],
        'auth' => ['registration_enabled', 'oauth_yandex_enabled', 'oauth_yandex_client_id', 'oauth_yandex_client_secret', 'oauth_yandex_redirect_uri'],
        'mail' => ['mail_enabled', 'mail_from_email', 'mail_from_name', 'mail_smtp_host', 'mail_smtp_port', 'mail_smtp_encryption', 'mail_smtp_user', 'mail_smtp_pass'],
        'maintenance' => ['maintenance_enabled', 'maintenance_title', 'maintenance_message', 'maintenance_until', 'maintenance_allowed_ips'],
    ];
}

function iro_settings_ensure_table(PDO $pdo): void
{
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS site_settings (
            setting_key VARCHAR(64) NOT NULL PRIMARY KEY,
            setting_value TEXT NOT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}

/** Строки из БД (только сохранённые ключи). Без таблицы — пустой массив. */
function iro_settings_stored(PDO $pdo, bool $reload = false): array
{
    static $cache = null;
    if ($cache !== null && !$reload) {
        return $cache;
    }
    $cache = [];
    try {
        $rows = $pdo->query('SELECT setting_key, setting_value FROM site_settings')->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $cache[(string) $r['setting_key']] = (string) $r['setting_value'];
        }
    } catch (PDOException $e) {
        $cache = [];
    }

    return $cache;
}

/**
 * Значения по умолчанию для полей, которые раньше задавались только в config.php,
 * чтобы форма открывалась с текущими рабочими значениями.
 */
function iro_settings_config_defaults(array $config): array
{
    $y = $config['oauth']['yandex'] ?? [];
    $m = $config['mail'] ?? [];
    $d = [];
    if (!empty($config['app']['name'])) {
        $d['site_name'] = (string) $config['app']['name'];
    }
    if (is_array($y)) {
        $d['oauth_yandex_enabled'] = !empty($y['enabled']) ? '1' : '0';
        $d['oauth_yandex_client_id'] = (string) ($y['client_id'] ?? '');
        $d['oauth_yandex_client_secret'] = (string) ($y['client_secret'] ?? '');
        $redirect = (string) ($y['redirect_uri'] ?? '');
        $d['oauth_yandex_redirect_uri'] = str_contains($redirect, 'example.ru') ? '' : $redirect;
    }
    if (is_array($m)) {
        $d['mail_enabled'] = !empty($m['enabled']) ? '1' : '0';
        foreach (['from_email', 'from_name', 'smtp_host', 'smtp_port', 'smtp_encryption', 'smtp_user', 'smtp_pass'] as $k) {
            if (isset($m[$k]) && (string) $m[$k] !== '') {
                $d['mail_' . $k] = (string) $m[$k];
            }
        }
        if (str_contains((string) ($d['mail_from_email'] ?? ''), 'example.ru')) {
            $d['mail_from_email'] = '';
        }
    }

    return $d;
}

/** Все настройки: БД → config.php → значение по умолчанию. */
function iro_settings_all(PDO $pdo, array $config): array
{
    $out = [];
    foreach (iro_settings_schema() as $key => [, $default]) {
        $out[$key] = $default;
    }

    return array_merge($out, iro_settings_config_defaults($config), iro_settings_stored($pdo));
}

function iro_setting(string $key, ?string $fallback = null): string
{
    $all = $GLOBALS['site_settings'] ?? [];
    if (array_key_exists($key, $all)) {
        return (string) $all[$key];
    }

    return (string) ($fallback ?? (iro_settings_schema()[$key][1] ?? ''));
}

function iro_setting_bool(string $key): bool
{
    return iro_setting($key) === '1';
}

/** Перенос настроек в структуру $config, которую читают mailer.php и oauth_yandex.php. */
function iro_settings_apply_to_config(array $config, array $s): array
{
    $config['app']['name'] = $s['site_name'] !== '' ? $s['site_name'] : ($config['app']['name'] ?? 'Конкурсы');
    $config['oauth']['yandex'] = array_merge($config['oauth']['yandex'] ?? [], [
        'enabled' => $s['oauth_yandex_enabled'] === '1',
        'client_id' => $s['oauth_yandex_client_id'],
        'client_secret' => $s['oauth_yandex_client_secret'],
        'redirect_uri' => $s['oauth_yandex_redirect_uri'] !== ''
            ? $s['oauth_yandex_redirect_uri']
            : iro_public_absolute_url('/auth/yandex/callback', $config),
    ]);
    $config['oauth']['yandex']['scope'] ??= 'login:email login:info';
    $config['mail'] = array_merge($config['mail'] ?? [], [
        'enabled' => $s['mail_enabled'] === '1',
        'from_email' => $s['mail_from_email'],
        'from_name' => $s['mail_from_name'] !== '' ? $s['mail_from_name'] : $config['app']['name'],
        'smtp_host' => $s['mail_smtp_host'],
        'smtp_port' => (int) $s['mail_smtp_port'],
        'smtp_encryption' => $s['mail_smtp_encryption'],
        'smtp_user' => $s['mail_smtp_user'],
        'smtp_pass' => $s['mail_smtp_pass'],
    ]);

    return $config;
}

/**
 * Сохранение секции. Пустое значение у secret-поля означает «не менять».
 * Возвращает список ошибок.
 */
function iro_settings_save_section(PDO $pdo, string $section, array $input): array
{
    $sections = iro_settings_sections();
    if (!isset($sections[$section])) {
        return ['Неизвестный раздел настроек.'];
    }
    $schema = iro_settings_schema();
    $values = [];
    $errors = [];
    foreach ($sections[$section] as $key) {
        [$type] = $schema[$key];
        if ($type === 'bool') {
            $values[$key] = !empty($input[$key]) ? '1' : '0';
            continue;
        }
        $raw = trim((string) ($input[$key] ?? ''));
        if ($type === 'secret' && $raw === '') {
            if (!empty($input[$key . '__clear'])) {
                $values[$key] = '';
            }
            continue;
        }
        if ($type === 'int') {
            $raw = (string) max(0, (int) $raw);
        }
        $values[$key] = $type === 'text' ? str_replace("\r\n", "\n", $raw) : $raw;
    }

    foreach (['contact_email', 'mail_from_email'] as $k) {
        if (($values[$k] ?? '') !== '' && filter_var($values[$k], FILTER_VALIDATE_EMAIL) === false) {
            $errors[] = 'Некорректный email: ' . $values[$k];
        }
    }
    foreach (['org_site_url', 'vk_url', 'oauth_yandex_redirect_uri'] as $k) {
        if (($values[$k] ?? '') !== '' && !preg_match('~^https?://~i', $values[$k])) {
            $errors[] = 'Ссылка должна начинаться с http:// или https://: ' . $values[$k];
        }
    }
    if (isset($values['mail_smtp_encryption']) && !in_array($values['mail_smtp_encryption'], ['ssl', 'tls', 'none'], true)) {
        $errors[] = 'Шифрование SMTP: ssl, tls или none.';
    }
    if (isset($values['mail_smtp_port']) && ((int) $values['mail_smtp_port'] < 1 || (int) $values['mail_smtp_port'] > 65535)) {
        $errors[] = 'Порт SMTP должен быть от 1 до 65535.';
    }
    if (($values['maintenance_until'] ?? '') !== '' && strtotime(str_replace('T', ' ', $values['maintenance_until'])) === false) {
        $errors[] = 'Некорректная дата окончания работ.';
    }
    if (($values['site_name'] ?? null) === '') {
        $errors[] = 'Укажите название сайта.';
    }
    if ($errors) {
        return $errors;
    }

    iro_settings_ensure_table($pdo);
    $st = $pdo->prepare(
        'INSERT INTO site_settings (setting_key, setting_value) VALUES (:k, :v)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
    );
    foreach ($values as $k => $v) {
        $st->execute(['k' => $k, 'v' => $v]);
    }
    iro_settings_stored($pdo, true);

    return [];
}

function iro_settings_set(PDO $pdo, string $key, string $value): void
{
    iro_settings_ensure_table($pdo);
    $pdo->prepare(
        'INSERT INTO site_settings (setting_key, setting_value) VALUES (:k, :v)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
    )->execute(['k' => $key, 'v' => $value]);
}

function iro_maintenance_enabled(): bool
{
    return iro_setting_bool('maintenance_enabled');
}

function iro_maintenance_ip_allowed(): bool
{
    $list = preg_split('/[\s,;]+/', iro_setting('maintenance_allowed_ips'), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $ip = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));

    return $ip !== '' && in_array($ip, $list, true);
}

/** Страницы, доступные при обслуживании, чтобы администратор мог войти. */
function iro_maintenance_path_allowed(string $uri): bool
{
    $uri = rtrim($uri, '/');

    return in_array($uri, ['/login', '/logout', '/auth/yandex', '/auth/yandex/callback'], true);
}

function iro_maintenance_render(): void
{
    $until = iro_setting('maintenance_until');
    $untilTs = $until !== '' ? strtotime(str_replace('T', ' ', $until)) : false;
    http_response_code(503);
    header('Cache-Control: no-store');
    if ($untilTs !== false && $untilTs > time()) {
        header('Retry-After: ' . max(60, $untilTs - time()));
    }
    $maintenance = [
        'title' => iro_setting('maintenance_title'),
        'message' => iro_setting('maintenance_message'),
        'until_label' => $untilTs !== false ? iro_format_datetime_long_ru(date('Y-m-d H:i:s', $untilTs)) : '',
        'site_name' => iro_setting('site_name'),
        'contact_email' => iro_setting('contact_email'),
        'contact_phone' => iro_setting('contact_phone'),
    ];
    require env_path('views/maintenance.php');
}
