-- Выполнить ОДИН раз после обновления кода с 'app' => ['timezone' => 'Asia/Chita'].
-- До исправления дата публикации новостей, введённая в форме по местному времени (UTC+9),
-- сохранялась в MySQL как UTC, поэтому новости считались «будущими» и не показывались.
SET time_zone = '+00:00';

UPDATE site_announcements
SET published_at = published_at - INTERVAL 9 HOUR;
