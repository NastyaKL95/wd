document.addEventListener('DOMContentLoaded', function () {
    var region = document.getElementById('region');
    var select = document.getElementById('municipality_select');
    var input = document.getElementById('municipality');
    if (!region || !select || !input) {
        return;
    }
    var homeRegion = region.getAttribute('data-home-region');

    // Отправляется только видимое поле: у второго disabled, и браузер его не передаёт.
    function sync() {
        var isHome = region.value === homeRegion;
        select.classList.toggle('d-none', !isHome);
        select.disabled = !isHome;
        input.classList.toggle('d-none', isHome);
        input.disabled = isHome;
    }

    region.addEventListener('change', sync);
    sync();
});
