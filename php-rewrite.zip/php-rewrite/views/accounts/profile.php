<section class="iro-panel iro-panel-narrow mx-auto">
    <h1 class="iro-page-title mb-3">Профиль</h1>
    <?php if (!empty($profile['id'])): ?>
        <p class="small text-muted mb-3">
            <a href="/profile/<?= (int) $profile['id'] ?>/">Как видят другие</a>
        </p>
    <?php endif; ?>
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $e): ?>
                <div><?= h((string) $e) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <form method="post" action="/profile" class="row g-3">
        <?= iro_csrf_field_html() ?>
        <div class="col-md-4">
            <label for="last_name" class="form-label">Фамилия</label>
            <input id="last_name" name="last_name" class="form-control" type="text" value="<?= h((string) ($profile['last_name'] ?? '')) ?>">
        </div>
        <div class="col-md-4">
            <label for="first_name" class="form-label">Имя</label>
            <input id="first_name" name="first_name" class="form-control" type="text" value="<?= h((string) ($profile['first_name'] ?? '')) ?>">
        </div>
        <div class="col-md-4">
            <label for="middle_name" class="form-label">Отчество</label>
            <input id="middle_name" name="middle_name" class="form-control" type="text" value="<?= h((string) ($profile['middle_name'] ?? '')) ?>">
        </div>
        <?php
        $regionVal = trim((string) ($profile['region'] ?? ''));
        $municipalityVal = trim((string) ($profile['municipality'] ?? ''));
        $isHomeRegion = $regionVal === IRO_HOME_REGION;
        $municipalitySelectVal = $isHomeRegion ? iro_normalize_municipality($municipalityVal) : '';
        $homeMunicipalities = iro_home_region_municipalities();
        $municipalityInList = in_array($municipalitySelectVal, iro_home_region_municipalities_flat(), true);
        ?>
        <div class="col-md-6">
            <label for="region" class="form-label">Регион</label>
            <select id="region" name="region" class="form-select" data-home-region="<?= h(IRO_HOME_REGION) ?>">
                <option value="">— Не выбран —</option>
                <?php if ($regionVal !== '' && !in_array($regionVal, iro_regions_list(), true)): ?>
                    <option value="<?= h($regionVal) ?>" selected><?= h($regionVal) ?> (указано ранее)</option>
                <?php endif; ?>
                <option value="<?= h(IRO_HOME_REGION) ?>"<?= $isHomeRegion ? ' selected' : '' ?>><?= h(IRO_HOME_REGION) ?></option>
                <option disabled>──────────</option>
                <?php foreach (iro_regions_list() as $r): ?>
                    <?php if ($r === IRO_HOME_REGION) {
                        continue;
                    } ?>
                    <option value="<?= h($r) ?>"<?= $regionVal === $r ? ' selected' : '' ?>><?= h($r) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-6">
            <label for="municipality" class="form-label">Муниципалитет</label>
            <select id="municipality_select" name="municipality" class="form-select<?= $isHomeRegion ? '' : ' d-none' ?>"<?= $isHomeRegion ? '' : ' disabled' ?> aria-label="Муниципалитет Забайкальского края">
                <option value="">— Выберите округ или город —</option>
                <?php if ($isHomeRegion && $municipalitySelectVal !== '' && !$municipalityInList): ?>
                    <option value="<?= h($municipalitySelectVal) ?>" selected><?= h($municipalitySelectVal) ?> (указано ранее)</option>
                <?php endif; ?>
                <?php foreach ($homeMunicipalities as $group => $items): ?>
                    <optgroup label="<?= h($group) ?>">
                        <?php foreach ($items as $m): ?>
                            <option value="<?= h($m) ?>"<?= $municipalitySelectVal === $m ? ' selected' : '' ?>><?= h($m) ?></option>
                        <?php endforeach; ?>
                    </optgroup>
                <?php endforeach; ?>
            </select>
            <input id="municipality" name="municipality" class="form-control<?= $isHomeRegion ? ' d-none' : '' ?>" type="text"<?= $isHomeRegion ? ' disabled' : '' ?>
                   placeholder="Город или район" value="<?= h($isHomeRegion ? '' : $municipalityVal) ?>">
        </div>
        <div class="col-12">
            <label for="school" class="form-label">Учебное заведение</label>
            <input id="school" name="school" class="form-control" type="text" value="<?= h((string) ($profile['school'] ?? '')) ?>">
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Сохранить</button>
        </div>
    </form>
</section>
