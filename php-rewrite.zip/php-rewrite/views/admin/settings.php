<?php
$s = $settings ?? [];
$tab = $settings_tab ?? 'general';
$posted = is_post() && (string) ($_POST['section'] ?? '') === $tab;
$val = static function (string $key) use ($s, $posted): string {
    if ($posted && array_key_exists($key, $_POST)) {
        return (string) $_POST[$key];
    }

    return (string) ($s[$key] ?? '');
};
$checked = static function (string $key) use ($s, $posted): string {
    $on = $posted ? !empty($_POST[$key]) : (($s[$key] ?? '0') === '1');

    return $on ? 'checked' : '';
};
$tabs = [
    'general' => ['bi-gear', 'Общие'],
    'auth' => ['bi-person-lock', 'Регистрация и вход'],
    'mail' => ['bi-envelope', 'Почта'],
    'maintenance' => ['bi-tools', 'Обслуживание'],
];
?>
<section>
    <h1 class="iro-page-title mb-3">Настройки сайта</h1>
    <p class="text-muted mb-4">Значения из этой страницы имеют приоритет над <code>app/config.php</code>.</p>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0 ps-3">
                <?php foreach ($errors as $e): ?>
                    <li><?= h((string) $e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <ul class="nav nav-tabs mb-0 flex-nowrap overflow-auto">
        <?php foreach ($tabs as $key => [$icon, $label]): ?>
            <li class="nav-item">
                <a class="nav-link text-nowrap<?= $tab === $key ? ' active' : '' ?>" href="/admin/settings?tab=<?= h($key) ?>"<?= $tab === $key ? ' aria-current="page"' : '' ?>>
                    <i class="bi <?= h($icon) ?> me-1"></i><?= h($label) ?>
                    <?php if ($key === 'maintenance' && ($s['maintenance_enabled'] ?? '0') === '1'): ?>
                        <span class="badge text-bg-warning ms-1">вкл</span>
                    <?php endif; ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>

    <form method="post" action="/admin/settings" class="iro-panel p-4 border-top-0 rounded-top-0 iro-form--w36r" style="max-width: 48rem">
        <?= iro_csrf_field_html() ?>
        <input type="hidden" name="section" value="<?= h($tab) ?>">

        <?php if ($tab === 'general'): ?>
            <div class="mb-3">
                <label class="form-label" for="site_name">Название сайта</label>
                <input type="text" class="form-control" id="site_name" name="site_name" required value="<?= h($val('site_name')) ?>">
                <div class="form-text">Показывается в заголовке вкладки браузера и в письмах.</div>
            </div>
            <div class="mb-3">
                <label class="form-label" for="org_name">Организация</label>
                <input type="text" class="form-control" id="org_name" name="org_name" value="<?= h($val('org_name')) ?>">
                <div class="form-text">Название в подвале сайта.</div>
            </div>
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label" for="contact_phone">Телефон</label>
                    <input type="text" class="form-control" id="contact_phone" name="contact_phone" value="<?= h($val('contact_phone')) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="contact_email">Email для связи</label>
                    <input type="email" class="form-control" id="contact_email" name="contact_email" value="<?= h($val('contact_email')) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="org_site_url">Сайт организации</label>
                    <input type="url" class="form-control" id="org_site_url" name="org_site_url" placeholder="https://…" value="<?= h($val('org_site_url')) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="vk_url">Группа ВКонтакте</label>
                    <input type="url" class="form-control" id="vk_url" name="vk_url" placeholder="https://vk.com/…" value="<?= h($val('vk_url')) ?>">
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label" for="footer_copyright">Копирайт в подвале</label>
                <div class="input-group" style="max-width: 24rem">
                    <span class="input-group-text">©</span>
                    <input type="text" class="form-control" id="footer_copyright" name="footer_copyright" value="<?= h($val('footer_copyright')) ?>">
                    <span class="input-group-text">, <?= h(date('Y')) ?></span>
                </div>
                <div class="form-text">Пустые поля контактов в подвале не выводятся.</div>
            </div>

        <?php elseif ($tab === 'auth'): ?>
            <h2 class="h6 text-uppercase text-muted mb-3">Регистрация</h2>
            <div class="form-check form-switch mb-4">
                <input class="form-check-input" type="checkbox" role="switch" id="registration_enabled" name="registration_enabled" value="1" <?= $checked('registration_enabled') ?>>
                <label class="form-check-label" for="registration_enabled">Разрешить регистрацию новых пользователей</label>
                <div class="form-text">Если выключить, форма регистрации закроется, а через Яндекс смогут войти только уже зарегистрированные пользователи.</div>
            </div>

            <h2 class="h6 text-uppercase text-muted mb-3">Вход через Яндекс</h2>
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" role="switch" id="oauth_yandex_enabled" name="oauth_yandex_enabled" value="1" <?= $checked('oauth_yandex_enabled') ?>>
                <label class="form-check-label" for="oauth_yandex_enabled">Показывать кнопку «Войти через Яндекс»</label>
            </div>
            <div class="mb-3">
                <label class="form-label" for="oauth_yandex_client_id">ClientID</label>
                <input type="text" class="form-control font-monospace" id="oauth_yandex_client_id" name="oauth_yandex_client_id" autocomplete="off" value="<?= h($val('oauth_yandex_client_id')) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label" for="oauth_yandex_client_secret">Client secret</label>
                <input type="password" class="form-control font-monospace" id="oauth_yandex_client_secret" name="oauth_yandex_client_secret" autocomplete="new-password"
                       placeholder="<?= ($s['oauth_yandex_client_secret'] ?? '') !== '' ? 'Сохранён — оставьте пустым, чтобы не менять' : 'Не задан' ?>">
            </div>
            <div class="mb-3">
                <label class="form-label" for="oauth_yandex_redirect_uri">Redirect URI</label>
                <input type="url" class="form-control font-monospace" id="oauth_yandex_redirect_uri" name="oauth_yandex_redirect_uri" placeholder="<?= h($yandex_callback_default ?? '') ?>" value="<?= h($val('oauth_yandex_redirect_uri')) ?>">
                <div class="form-text">
                    Пусто — используется <code><?= h($yandex_callback_default ?? '') ?></code>.
                    Этот же адрес укажите в приложении на <a href="https://oauth.yandex.ru/" target="_blank" rel="noopener">oauth.yandex.ru</a>
                    (платформа «Веб-сервисы», доступы: почта и имя пользователя).
                </div>
            </div>
            <?php if (($s['oauth_yandex_enabled'] ?? '0') === '1' && (($s['oauth_yandex_client_id'] ?? '') === '' || ($s['oauth_yandex_client_secret'] ?? '') === '')): ?>
                <div class="alert alert-warning small">Вход включён, но не заполнены ClientID или Client secret — кнопка на сайте не появится.</div>
            <?php endif; ?>

        <?php elseif ($tab === 'mail'): ?>
            <p class="text-muted small">Используется для писем восстановления пароля.</p>
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" role="switch" id="mail_enabled" name="mail_enabled" value="1" <?= $checked('mail_enabled') ?>>
                <label class="form-check-label" for="mail_enabled">Отправлять письма</label>
            </div>
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label" for="mail_from_email">Email отправителя</label>
                    <input type="email" class="form-control" id="mail_from_email" name="mail_from_email" placeholder="noreply@…" value="<?= h($val('mail_from_email')) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="mail_from_name">Имя отправителя</label>
                    <input type="text" class="form-control" id="mail_from_name" name="mail_from_name" placeholder="<?= h((string) ($s['site_name'] ?? '')) ?>" value="<?= h($val('mail_from_name')) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="mail_smtp_host">SMTP-сервер</label>
                    <input type="text" class="form-control" id="mail_smtp_host" name="mail_smtp_host" placeholder="smtp.yandex.ru" value="<?= h($val('mail_smtp_host')) ?>">
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label" for="mail_smtp_port">Порт</label>
                    <input type="number" min="1" max="65535" class="form-control" id="mail_smtp_port" name="mail_smtp_port" value="<?= h($val('mail_smtp_port')) ?>">
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label" for="mail_smtp_encryption">Шифрование</label>
                    <select class="form-select" id="mail_smtp_encryption" name="mail_smtp_encryption">
                        <?php foreach (['ssl' => 'SSL (465)', 'tls' => 'STARTTLS (587)', 'none' => 'Нет'] as $ek => $el): ?>
                            <option value="<?= h($ek) ?>" <?= $val('mail_smtp_encryption') === $ek ? 'selected' : '' ?>><?= h($el) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="mail_smtp_user">Логин SMTP</label>
                    <input type="text" class="form-control" id="mail_smtp_user" name="mail_smtp_user" autocomplete="off" value="<?= h($val('mail_smtp_user')) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="mail_smtp_pass">Пароль SMTP</label>
                    <input type="password" class="form-control" id="mail_smtp_pass" name="mail_smtp_pass" autocomplete="new-password"
                           placeholder="<?= ($s['mail_smtp_pass'] ?? '') !== '' ? 'Сохранён — оставьте пустым, чтобы не менять' : 'Не задан' ?>">
                    <div class="form-text">Для Яндекс-почты нужен пароль приложения.</div>
                </div>
            </div>

        <?php elseif ($tab === 'maintenance'): ?>
            <?php if (($s['maintenance_enabled'] ?? '0') === '1'): ?>
                <div class="alert alert-warning small">Режим обслуживания сейчас <strong>включён</strong>. Администраторы видят сайт как обычно.</div>
            <?php endif; ?>
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" role="switch" id="maintenance_enabled" name="maintenance_enabled" value="1" <?= $checked('maintenance_enabled') ?>>
                <label class="form-check-label" for="maintenance_enabled">Включить режим технического обслуживания</label>
                <div class="form-text">Посетители и пользователи без роли администратора увидят страницу-заглушку (HTTP 503). Страница входа остаётся доступной.</div>
            </div>
            <div class="mb-3">
                <label class="form-label" for="maintenance_title">Заголовок</label>
                <input type="text" class="form-control" id="maintenance_title" name="maintenance_title" value="<?= h($val('maintenance_title')) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label" for="maintenance_message">Сообщение для посетителей</label>
                <textarea class="form-control" id="maintenance_message" name="maintenance_message" rows="4"><?= h($val('maintenance_message')) ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label" for="maintenance_until">Планируемое окончание работ</label>
                <input type="datetime-local" class="form-control" id="maintenance_until" name="maintenance_until" style="max-width: 16rem" value="<?= h($val('maintenance_until')) ?>">
                <div class="form-text">Необязательно. Режим сам не выключится — это только подсказка посетителям.</div>
            </div>
            <div class="mb-3">
                <label class="form-label" for="maintenance_allowed_ips">IP-адреса с доступом к сайту</label>
                <textarea class="form-control font-monospace" id="maintenance_allowed_ips" name="maintenance_allowed_ips" rows="2" placeholder="Через запятую или с новой строки"><?= h($val('maintenance_allowed_ips')) ?></textarea>
                <div class="form-text">Например, для проверки сайта без входа. Ваш текущий IP: <code><?= h($client_ip ?? '') ?></code></div>
            </div>
        <?php endif; ?>

        <button type="submit" class="btn btn-primary rounded-pill px-4">Сохранить</button>
    </form>

    <?php if ($tab === 'mail'): ?>
        <form method="post" action="/admin/settings/test-mail" class="iro-panel p-4 mt-3" style="max-width: 48rem">
            <?= iro_csrf_field_html() ?>
            <h2 class="h6 mb-3">Проверка отправки</h2>
            <?php if (empty($mail_ready)): ?>
                <p class="small text-muted">Сначала включите отправку и сохраните отправителя, сервер, логин и пароль.</p>
            <?php endif; ?>
            <div class="input-group" style="max-width: 32rem">
                <input type="email" name="to" class="form-control" required value="<?= h((string) ($user['email'] ?? '')) ?>" aria-label="Email получателя">
                <button type="submit" class="btn btn-outline-primary"<?= empty($mail_ready) ? ' disabled' : '' ?>>Отправить тестовое письмо</button>
            </div>
        </form>
    <?php endif; ?>
</section>
