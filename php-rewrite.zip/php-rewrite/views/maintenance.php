<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <title><?= h($maintenance['title'] . ' — ' . $maintenance['site_name']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/assets/css/styles.css">
    <link rel="icon" href="/assets/img/iro-brand.png" type="image/png" sizes="any">
</head>
<body class="d-flex flex-column min-vh-100 bg-light">
<main class="flex-grow-1 d-flex align-items-center py-5">
    <div class="container" style="max-width: 40rem">
        <div class="iro-panel text-center p-4 p-md-5">
            <i class="bi bi-tools display-4 d-block mb-3 text-primary" aria-hidden="true"></i>
            <h1 class="iro-page-title mb-3"><?= h($maintenance['title']) ?></h1>
            <?php if ($maintenance['message'] !== ''): ?>
                <p class="iro-lead mb-3"><?= nl2br(h($maintenance['message'])) ?></p>
            <?php endif; ?>
            <?php if ($maintenance['until_label'] !== ''): ?>
                <p class="mb-3"><strong>Планируемое окончание работ:</strong> <?= h($maintenance['until_label']) ?></p>
            <?php endif; ?>
            <?php if ($maintenance['contact_email'] !== '' || $maintenance['contact_phone'] !== ''): ?>
                <p class="small text-muted mb-0">
                    Связаться с нами:
                    <?php if ($maintenance['contact_phone'] !== ''): ?>
                        <a href="tel:<?= h(preg_replace('/[^\d+]/', '', $maintenance['contact_phone'])) ?>"><?= h($maintenance['contact_phone']) ?></a>
                    <?php endif; ?>
                    <?php if ($maintenance['contact_email'] !== '' && $maintenance['contact_phone'] !== ''): ?> · <?php endif; ?>
                    <?php if ($maintenance['contact_email'] !== ''): ?>
                        <a href="mailto:<?= h($maintenance['contact_email']) ?>"><?= h($maintenance['contact_email']) ?></a>
                    <?php endif; ?>
                </p>
            <?php endif; ?>
        </div>
        <p class="text-center small mt-3 mb-0"><a href="/login" class="text-muted">Вход для администраторов</a></p>
    </div>
</main>
</body>
</html>
